<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8"/>
  <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no"/>
  <meta name="description" content=""/>
  <meta name="author" content=""/>
  <title>Dashtreme Admin - Free Dashboard for Bootstrap 4 by Codervent</title>
  <!-- loader-->
  <link href="{{ asset('assets/css/pace.min.css') }}" rel="stylesheet"/>
<script src="{{ asset('assets/js/pace.min.js') }}"></script>
<!--favicon-->
<link rel="icon" href="{{ asset('assets/images/favicon.ico') }}" type="image/x-icon">
<!-- simplebar CSS-->
<link href="{{ asset('assets/plugins/simplebar/css/simplebar.css') }}" rel="stylesheet"/>
<!-- Bootstrap core CSS-->
<link href="{{ asset('assets/css/bootstrap.min.css') }}" rel="stylesheet"/>
<!-- animate CSS-->
<link href="{{ asset('assets/css/animate.css') }}" rel="stylesheet" type="text/css"/>
<!-- Icons CSS-->
<link href="{{ asset('assets/css/icons.css') }}" rel="stylesheet" type="text/css"/>
<!-- Sidebar CSS-->
<link href="{{ asset('assets/css/sidebar-menu.css') }}" rel="stylesheet"/>
<!-- Custom Style-->
<link href="{{ asset('assets/css/app-style.css') }}" rel="stylesheet"/>

</head>

<body class="bg-theme bg-theme1">

<!-- start loader -->
   <div id="pageloader-overlay" class="visible incoming"><div class="loader-wrapper-outer"><div class="loader-wrapper-inner" ><div class="loader"></div></div></div></div>
   <!-- end loader -->

<!-- Start wrapper-->
 <div id="wrapper">

 <!--Start sidebar-wrapper-->
   <div id="sidebar-wrapper" data-simplebar="" data-simplebar-auto-hide="true">
     <div class="brand-logo">
      <a href="index.html">
       <img src="assets/images/logo-icon.png" class="logo-icon" alt="logo icon">
       <h5 class="logo-text">Dashtreme Admin</h5>
     </a>
   </div>
   <ul class="sidebar-menu do-nicescrol">
      <li class="sidebar-header">MAIN NAVIGATION</li>
      <li>
      <a href="{{ route('admin') }}">
          <i class="zmdi zmdi-view-dashboard"></i> <span>Dashboard</span>
        </a>
      </li>

      <li>
        <a href="icons.html">
          <i class="zmdi zmdi-invert-colors"></i> <span>UI Icons</span>
        </a>
      </li>
<li>
      <a href="{{ route('form') }}">
        <i class="zmdi zmdi-format-list-bulleted"></i> <span>Cities</span>
    </a>
    <ul> <!-- Nested unordered list for submenu -->
        <li>
            <a href="{{ route('form') }}">
                <i class="zmdi zmdi-plus"></i> <span>Add City</span>
            </a>
        </li>
        <li>
        
            <a href="{{ route('allcities') }}"> <!-- Assuming you've defined a route named 'all-cities' -->
                <i class="zmdi zmdi-view-list"></i> <span>All Cities</span>
            </a>
        </li>
    </ul>
</li>

      <li>
        <a href="{{ route('add.industry') }}">
          <i class="zmdi zmdi-grid"></i> <span>industry</span>
        </a>
      </li>

      <li>
        <a href="calendar.html">
          <i class="zmdi zmdi-calendar-check"></i> <span>Calendar</span>
          <small class="badge float-right badge-light">New</small>
        </a>
      </li>

      <li>
        <a href="profile.html">
          <i class="zmdi zmdi-face"></i> <span>Profile</span>
        </a>
      </li>

      <li>
        <a href="login.html" target="_blank">
          <i class="zmdi zmdi-lock"></i> <span>Login</span>
        </a>
      </li>

       <li>
        <a href="register.html" target="_blank">
          <i class="zmdi zmdi-account-circle"></i> <span>Registration</span>
        </a>
      </li>
	  
      <li class="sidebar-header">LABELS</li>
      <li><a href="javaScript:void();"><i class="zmdi zmdi-coffee text-danger"></i> <span>Important</span></a></li>
      <li><a href="javaScript:void();"><i class="zmdi zmdi-chart-donut text-success"></i> <span>Warning</span></a></li>
      <li><a href="javaScript:void();"><i class="zmdi zmdi-share text-info"></i> <span>Information</span></a></li>

    </ul>
   
   </div>
   <!--End sidebar-wrapper-->
  


<!--End topbar header-->
<div class="content">
  <div class="container-fluid">
    <div class="row mt-3">
      <div class="col-lg-6 mx-auto"> <!-- Centering content -->
        <div class="content">
          <div class="card-body">
            <div class="card-title">Add Industry</div>
            <hr>
            <div class="container mt-5">
              @if (session('success'))
                <div class="alert alert-success">
                  {{ session('success') }}
                </div>
              @endif

              @if ($errors->any())
                <div class="alert alert-danger">
                  <ul>
                    @foreach ($errors->all() as $error)
                      <li>{{ $error }}</li>
                    @endforeach
                  </ul>
                </div>
              @endif

              <form action="{{ route('industries.store') }}" method="POST">
    @csrf

    <!-- Industry Input -->
    <div class="form-group">
        <label for="industry"><b>Industry</b></label>
        <input type="text" class="form-control" id="industry" name="industry" placeholder="Enter Industry Name" value="{{ old('industry') }}">
    </div>

    <!-- Initial City, Accommodation, and Field Input -->
    <div class="form-group">
        <div class="row">
            <div class="col-md-6">
                <label for="city-0"><b>City</b></label>
                <input type="text" class="form-control" id="city-0" name="cities[]" placeholder="Enter City Name" value="{{ old('cities.0') }}">
            </div>
            <div class="col-md-6 align-self-end">
                <div class="form-group form-check">
                    <input type="checkbox" class="form-check-input" id="accommodation-0" name="accommodations[]" {{ old('accommodations.0') ? 'checked' : '' }}>
                    <label class="form-check-label" for="accommodation-0"><b>Accommodation</b></label>
                </div>
            </div>
        </div>
        <div class="row mt-3">
            <div class="col-md-12">
                <label for="field-0"><b>Field</b></label>
                <div class="input-group">
                    <input type="text" class="form-control" id="field-0" name="fields[]" placeholder="Enter Field" value="{{ old('fields.0') }}">
                    <div class="input-group-append">
                        <button class="btn btn-primary" type="button" onclick="addFieldTag(0)">Add Tag</button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Dynamic City, Accommodation, and Field Inputs -->
    <div id="dynamic-form">
        @if (old('cities'))
            @for ($i = 1; $i < count(old('cities')); $i++)
                <div class="form-group" id="form-group-{{ $i }}">
                    <div class="row">
                        <div class="col-md-6">
                            <label for="city-{{ $i }}"><b>City</b></label>
                            <input type="text" class="form-control" id="city-{{ $i }}" name="cities[]" placeholder="Enter City Name" value="{{ old('cities.' . $i) }}">
                        </div>
                        <div class="col-md-6 align-self-end">
                            <div class="form-group form-check">
                                <input type="checkbox" class="form-check-input" id="accommodation-{{ $i }}" name="accommodations[]" {{ old('accommodations.' . $i) ? 'checked' : '' }}>
                                <label class="form-check-label" for="accommodation-{{ $i }}"><b>Accommodation</b></label>
                            </div>
                        </div>
                    </div>
                    <div class="row mt-3">
                        <div class="col-md-12">
                            <label for="field-{{ $i }}"><b>Field</b></label>
                            <div class="input-group">
                                <input type="text" class="form-control" id="field-{{ $i }}" name="fields[]" placeholder="Enter Field" value="{{ old('fields.' . $i) }}">
                                <div class="input-group-append">
                                    <button class="btn btn-primary" type="button" onclick="addFieldTag({{ $i }})">Add Tag</button>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row mt-3" id="field-tags-{{ $i }}">
                        <!-- Field Tags will be appended here -->
                    </div>
                    <div class="row mt-3">
                        <div class="col-md-12">
                            <button type="button" class="btn btn-danger" onclick="removeFormGroup({{ $i }})">Remove</button>
                        </div>
                    </div>
                </div>
            @endfor
        @endif
    </div>

    <!-- Button to Add More Fields -->
    <div class="form-group">
        <button type="button" class="btn btn-secondary" id="add-more">Add More</button>
    </div>

    <!-- Submit Button -->
    <div class="form-group">
        <button type="submit" class="btn btn-primary">Submit</button>
    </div>
</form>
<script>
    let formGroupIndex = {{ old('cities') ? count(old('cities')) : 1 }};

    document.getElementById('add-more').addEventListener('click', function () {
        const newFormGroup = document.createElement('div');
        newFormGroup.classList.add('form-group');
        newFormGroup.id = `form-group-${formGroupIndex}`;
        newFormGroup.innerHTML = `
            <div class="row">
                <div class="col-md-6">
                    <label for="city-${formGroupIndex}"><b>City</b></label>
                    <input type="text" class="form-control" id="city-${formGroupIndex}" name="cities[]" placeholder="Enter City Name">
                </div>
                <div class="col-md-6 align-self-end">
                    <div class="form-group form-check">
                        <input type="checkbox" class="form-check-input" id="accommodation-${formGroupIndex}" name="accommodations[]">
                        <label class="form-check-label" for="accommodation-${formGroupIndex}"><b>Accommodation</b></label>
                    </div>
                </div>
            </div>
            <div class="row mt-3">
                <div class="col-md-12">
                    <label for="field-${formGroupIndex}"><b>Field</b></label>
                    <div class="input-group">
                        <input type="text" class="form-control" id="field-${formGroupIndex}" name="fields[]" placeholder="Enter Field">
                        <div class="input-group-append">
                            <button class="btn btn-primary add-tag" type="button">Add Tag</button>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row mt-3" id="field-tags-${formGroupIndex}">
                <!-- Field Tags will be appended here -->
            </div>
            <div class="row mt-3">
                <div class="col-md-12">
                    <button type="button" class="btn btn-danger" onclick="removeFormGroup(${formGroupIndex})">Remove</button>
                </div>
            </div>
        `;
        document.getElementById('dynamic-form').appendChild(newFormGroup);
        formGroupIndex++;
    });

    function removeFormGroup(index) {
        const formGroup = document.getElementById(`form-group-${index}`);
        formGroup.remove();
    }

    function addFieldTag(cityIndex) {
        const fieldInput = document.getElementById(`field-${cityIndex}`);
        const fieldTagName = fieldInput.value.trim();
        if (fieldTagName !== '') {
            const fieldTagsContainer = document.getElementById(`field-tags-${cityIndex}`);
            const fieldTag = document.createElement('span');
            fieldTag.classList.add('badge', 'badge-primary', 'mr-2');
            fieldTag.textContent = fieldTagName;
            const deleteButton = document.createElement('button');
            deleteButton.classList.add('btn', 'btn-sm', 'btn-danger');
            deleteButton.textContent = 'x';
            deleteButton.addEventListener('click', function () {
                // Remove the field from the DOM
                fieldTag.remove();
                // Optionally, you can also remove the field from the database via an AJAX request
            });
            fieldTag.appendChild(deleteButton);
            fieldTagsContainer.appendChild(fieldTag);
            // Clear the field input
            fieldInput.value = '';
        }
    }

    // Add event listeners for dynamically added "Add Tag" buttons
    document.getElementById('dynamic-form').addEventListener('click', function(event) {
        if (event.target.classList.contains('add-tag')) {
            const formGroup = event.target.closest('.form-group');
            const cityIndex = formGroup.id.split('-').pop();
            addFieldTag(cityIndex);
        }
    });

    // Add event listeners for initial "Add Tag" buttons
    const initialAddTagButtons = document.querySelectorAll('.add-tag');
    initialAddTagButtons.forEach(button => {
        button.addEventListener('click', function() {
            const formGroup = button.closest('.form-group');
            const cityIndex = formGroup.id.split('-').pop();
            addFieldTag(cityIndex);
        });
    });

    // Function to add initial field tags
    document.addEventListener('DOMContentLoaded', function () {
        const initialFieldTagsContainers = document.querySelectorAll('[id^="field-tags-"]');
        initialFieldTagsContainers.forEach(container => {
            const cityIndex = container.id.split('-').pop();
            const fieldInput = document.getElementById(`field-${cityIndex}`);
            const fieldTags = fieldInput.value.split(',').map(tag => tag.trim()).filter(tag => tag !== '');
            fieldTags.forEach(tag => {
                const fieldTag = document.createElement('span');
                fieldTag.classList.add('badge', 'badge-primary', 'mr-2');
                fieldTag.textContent = tag;
                const deleteButton = document.createElement('button');
                deleteButton.classList.add('btn', 'btn-sm', 'btn-danger');
                deleteButton.textContent = 'x';
                deleteButton.addEventListener('click', function () {
                    // Remove the field from the DOM
                    fieldTag.remove();
                    // Optionally, you can also remove the field from the database via an AJAX request
                });
                fieldTag.appendChild(deleteButton);
                container.appendChild(fieldTag);
            });
        });
    });
</script>




            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
   
   
  <!-- Bootstrap core JavaScript-->
  <script src="assets/js/jquery.min.js"></script>
  <script src="assets/js/popper.min.js"></script>
  <script src="assets/js/bootstrap.min.js"></script>
	
 <!-- simplebar js -->
  <script src="assets/plugins/simplebar/js/simplebar.js"></script>
  <!-- sidebar-menu js -->
  <script src="assets/js/sidebar-menu.js"></script>
  
  <!-- Custom scripts -->
  <script src="assets/js/app-script.js"></script>
	
</body>
</html>
