<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Industry as IndustryModel;

class Industry extends Controller
{
    /**
     * Store a newly created industry in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $validatedData = $request->validate([
            'industry' => 'required|string|max:255',
            'cities' => 'required|array',
            'cities.*' => 'required|string|max:255',
            'accommodations' => 'array',
            'fields' => 'required|array',
            'fields.*' => 'required|string|max:255',
        ]);

        foreach ($validatedData['cities'] as $index => $city) {
            $accommodation = isset($validatedData['accommodations'][$index]) ? 'yes' : 'no';
            IndustryModel::create([
                'industry' => $validatedData['industry'],
                'city' => $city,
                'field' => $validatedData['fields'][$index],
                'accommodation' => $accommodation,
            ]);
        }

        return redirect()->back()->with('success', 'Industry information saved successfully.');
    }
    public function deleteField($industryId, $fieldId)
{
    $industry = IndustryModel::find($industryId);
    if (!$industry) {
        return response()->json(['error' => 'Industry not found'], 404);
    }

    $field = $industry->fields()->find($fieldId);
    if (!$field) {
        return response()->json(['error' => 'Field not found'], 404);
    }

    $field->delete();

    return response()->json(['message' => 'Field deleted successfully'], 200);
}

}
