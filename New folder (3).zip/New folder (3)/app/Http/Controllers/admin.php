<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\City; // Import the City model

class admin extends Controller
{
    public function display()
    {
        return view('index');
    }

    public function form()
    {
        $cities = City::all(); // Fetch all cities
        return view('addcity', compact('cities'));
    }

    public function icon()
    {
        return view('icons');
    }

    public function login()
    {
        return view('login');
    }

    public function profile()
    {
        return view('profile');
    }

    public function register()
    {
        return view('register');
    }

    public function passwordreset()
    {
        return view('reset-password');
    }

    public function add_industry()
    {
        return view('addindustry');
    }
}
